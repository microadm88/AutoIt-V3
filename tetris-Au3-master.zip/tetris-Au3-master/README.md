# tetris-Au3
A simple Tetris game made in AutoIt

This was my first game i made in AutoIt back in 2013.

The main focus were to have a low CPU usage game, and to understand game mechanics better.
