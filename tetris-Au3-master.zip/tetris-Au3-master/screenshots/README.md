Screenshots taken during development

Showing interresting bugs and small changes during the development process
