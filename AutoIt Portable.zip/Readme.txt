
  AutoIt Portable V1.6.3.10

-----------------------------

Website: http://softwarespot.wordpress.com/code/autoit-portable/
Language: Multi-language

  Description
-----------------------------
AutoIt Portable is a portable wrapper for AutoIt and SciTE4AutoIt3. It ensures SciTE doesn't leave any traces on the users machine. To install you can either use the AutoIt Creator or manually create the AutoIt package by following the instructions below.

Download references:
AutoIt [http://www.autoitscript.com/]
SciTE4AutoIt3 [http://www.autoitscript.com/site/autoit-script-editor/]


  GUI
-----------------------------
If you're are new to AutoIt and would like to see what Examples are available in AutoIt or are just interested in how to structure AutoIt code, then simply select the example and it will display in SciTE. If you would like to run the example then select Tools >> Go (F5) within SciTE.

If you don't want the GUI to be shown everytime AutoIt Portable is run, then select the appropriate checkbox and this will delete an empty file called AutoItPortable.dat.

The following HotKeys are supported:
None


  AutoItPortable.ini
-----------------------------
By default AutoIt Portable configures SciTE to not save anything to its own directory e.g. session files or recently opened files. But with the AutoItPortable.ini file these settings can be changed to override the default behaviour of AutoIt Portable.

Buffers - [Default: 15] This value denotes how many tabs should be open at any one time in SciTE.
SaveRecent - [Default: 0] Save a list of the recently opened files so they can be accessed via the File menu.
SaveSession - [Default: 0] Save the current session when SciTE is closed.
SavePosition - [Default: 0] Save the position of SciTE.
SaveBookmarks - [Default: 0] Save the bookmarks added to SciTE in the session file.
SessionFolds - [Default: 0] Save the folded sates of the script to the session file.

To find out more about the individual settings then please visit http://www.scintilla.org/SciTEDoc.html.


  Commandline arguments
-----------------------------
Dropping an .au3 on the AutoIt Portable executable will open the file directly in SciTE.


  Extended functionality
-----------------------------
Enter - If a TreeView item is selected and the enter key is pressed it will open the file in SciTE.


How to Install
-----------------------------
To install AutoIt Portable you will need to download the following files from AutoIt directly. Please download before proceeding.

Download (ZIP) SciTe4AutoIt3: http://www.autoitscript.com/cgi-bin/getfile.pl?../autoit3/scite/download/SciTE4AutoIt3.zip
Download (Self-Extracting) AutoIt: http://www.autoitscript.com/cgi-bin/getfile.pl?autoit3/autoit-v3-sfx.exe

Once you've downloaded the files and saved to the same location then follow the steps below to create AutoIt Portable.

:: Automatic :: (Recommnded)
This is by far the easiest way to create AutoIt Portable as if requires no knowledge whatsoever. Simply start the AutoIt Creator application and drop both files (downloaded previously) onto the GUI, this will then proceed to create the structure required for AutoIt Portable. Additional settings can be accessed via the right-click contextmenu, these include changing the language of AutoIt Creator & cleaning up redundant files within AutoIt.

:: Manual :: (If you are unsure, then please follow the tutorial above.)
All files are copied to a folder called 'App', this can be found in the same directory as where the contents of AutoIt Portable is.
1. Extract SciTe4AutoIt3.zip and autoit-v3-sfx.exe. In 7-Zip the option to select would be 'Extract to <FileName>\' e.g. <FileName> could be autoit-v3-sfx.
2. Copy the contents of the 'SciTE4AutoIt3' folder to the SciTe folder found inside the 'App' folder.
3. Inside the 'autoit-v3-sfx' folder you'll find a second folder called 'install', copy the contents of this folder to the 'App' folder (not the SciTe folder.) 
3. Start AutoIt.exe.


  Temporarily install AutoIt Portable
-----------------------------
Sometimes certain examples in the help file require AutoIt to be installed, normally due to images being used from the 'Example' folder. Therefore as a temporary workaround selecting AutoIt Portable Install.exe will fix this problem by adding the required registry keys (see the AutoIt help file.) To remove from the registry just select AutoIt Portable Install.exe again. A file called AutoItRegistry.dat will be created when the registry keys have been added, if removed this file is deleted. Also note that the .au3 filetype will be registered to open up with AutoIt Portable.

Note: If you have an installed version of AutoIt on the system an error message will display stating an installed version is present.


  Thanks
-----------------------------
I would like to extend a big thank you to all who took the time to test the application in it's infancy as well as showing my gratitude to webfork for his input in the GUI creation.

This program wouldn't have been possible without the wonderful AutoIt community [http://www.autoitscript.com/forum/]

  License
-----------------------------
AutoIt Portable is released under GPLv3 (please see License.txt for more details) and all credit should be made towards the original authors.

AutoIt Portable also uses 7-Zip [7za.exe] by Igor Pavlov, therefore please read the license agreement for 7-Zip.


  ChangeLog
-----------------------------
Version 1.6.3.10 [29-03-2012]
- FIXED: Issue where AutoIt Creator would detect an unexpected error if dropping one file at a time.
- IMPROVED: Layout of source code for those wanting to learn AutoIt.
- IMPROVED: Overall memory consumption and CPU usage.

Version 1.5.3.7 [23-01-2012]
- ADDED: French translation. (Thanks to Ricky)
- FIXED: Issue with long strings not displaying.

Version 1.4.2.6 [04-01-2012]
- ADDED: AutoIt Portable Install.exe now registers the .au3 filetype to open with SciTE.

Version 1.3.1.6 [31-12-2011]
- ADDED: The INI file AutoItPortable.ini to override certain settings in SciTE. See above for more details.

Version 1.2.0.6 [28-12-2011]
- UPDATED: AutoIt Portable Install.exe by creating a symlink in C:\Program Files\AutoIt\ to AutoIt Portable (only works on Vista and above.)

Version 1.1.0.5 [23-12-2011]
- UPDATED: Compiled using the latest version of AutoIt V3.3.8.0.
- UPDATED: Tidied up the source code and removed duplicate functions by creating a single include file.

Version 1.0.0.3 [10-12-2011]
- ADDED: AutoIt Portable Install.exe to temporarily install AutoIt Portable to the registry to mimic as though it was installed.
- UPDATED: Now using AutoIt Beta V3.3.7.22.
- UPDATED: Source code.

Version 1.0.0.2 [02-08-2011]
- ADDED: Hotkey enter for opening a selected file in SciTE when the enter key is selected.
- ADDED: Only one instance of AutoIt Portable (not including SciTE) can be run.
- ADDED: New program called AutoIt Creator to create a Portable version automatically.
- ADDED: Multi-language support.
- FIXED: Small UI tweaks.
- UPDATED: Readme file.

Version 1.0.0.1 [14-07-2011]
- ADDED: Can now toggle between double/single-click for selecting an Example. Selection value is stored in the .dat file.

Version 1.0.0.0 [11-07-2011]
- Initial release.

-----------------------------