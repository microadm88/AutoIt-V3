# AutoIt-Android-Game-Script
AutoIt script that helped me win an event in an Android game. The point of the event was to accumulate points by constructing buildings in the game. This script checked if I had enough resources to build, built a building, upgrade the building to a certain level, then destroy it and rinse and repeat.
