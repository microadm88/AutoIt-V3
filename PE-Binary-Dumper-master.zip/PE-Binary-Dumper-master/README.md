# PE-Binary-Dumper
AutoIt PE ( EXE ) Binary Dumper - Very Useful
- You may need this tool to run a PE from memory.
- Or to write your PE, ...etc
- You can read more about it ...
- Ps : These result of strings you get , works only as AutoIt scripts/programs .

![alt text](screenshot_pebd.bmp "nag !")

> EOF
