# PianoTilesAutoit
A bot that plays the game Piano Tiles or Don't Top The White Tiles.

Goal: 
    - Consistantly scoring super human like scores. 

How to use:
    - Open game on chrome, link found in "useful links."
    - Start the autoit program. 
    - Press control+S to set up the position of the left most piano tile.
        note: positioning might effect the overall score. 
    - Press control+A to start the bot. Make sure the game window is active.
    - While the game is being played, position the mouse curser in the expected "play agian" button.
    
    
Useful links:
    - The game: http://tanksw.com/piano-tiles/


