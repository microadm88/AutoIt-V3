# Board-Games
Square board games like Chess or Checker in AutoIt

I am seeing if GIT will help me.

I wrote a Chess Email program in late 1990 and early 2000.  But got tired of trying MS C++.  Now that I am not work busy I need something to keep be active.

// Chess, Correspondence
// Version 0.52 - Aug 04, 2004
// Copyright © Phillip Forrestal 2002 - 2004