This "Extras" contains various utilties and files for use with AutoIt.  Some have been
created by the AutoIt team and others have been kindly supplied by users of AutoIt.


